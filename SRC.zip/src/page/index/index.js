import './index.scss';
import 'normalize.css';

import '../../components/modal/index.js';



